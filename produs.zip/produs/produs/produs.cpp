﻿#include <iostream>
using namespace std;

class Produs {
public:
    virtual void setName(const string& name) = 0;
    virtual void setPrice(double price) = 0;
    virtual void setStock(int stock) = 0;
    virtual void setCuloare(const string& culoare) = 0;
    virtual void setGB(int gb) = 0;
    virtual void display() const = 0;

};

class Samsung :public Produs {
private:
    string name_;
    double price_;
    int stock_;
    string culoare_;
    int gb_;
public:
    void setName(const string& name) override {
        name_ = name;
    }

    void setPrice(double price) override {
        price_ = price;
    }

    void setStock(int stock) override {
        stock_ = stock;
    }

    void setCuloare(const string& culoare) override {
        culoare_ = culoare;
    }

    void setGB(int gb) override {
        gb_ = gb;
    }


    void display() const {
        cout << "Primul Produs: " << name_
            << ", Price: " << price_
            << ", Stock: " << stock_
            << ", Culoare: " << culoare_
            << " , Stocare: " << gb_
            << endl;
    }

};

class Iphone :public Produs {
private:
    string name_;
    double price_;
    int stock_;
    string culoare_;
    int gb_;
public:
    void setName(const string& name) override {
        name_ = name;
    }

    void setPrice(double price) override {
        price_ = price;
    }

    void setStock(int stock) override {
        stock_ = stock;
    }

    void setCuloare(const string& culoare) override {
        culoare_ = culoare;
    }

    void setGB(int gb) override {
        gb_ = gb;
    }

    void display() const {
        cout << "Al doilea Produs: " << name_
            << ", Price: " << price_
            << ", Stock: " << stock_
            << ", Culoare: " << culoare_
            << " , Stocare: " << gb_
            << endl;
    }
};

class Factory {
public:
    virtual Produs* createProdus() = 0;
};

class FactoryA :public Factory {
public:
    virtual Produs* createProdus() override {
        return new Samsung();
    }
};

class FactoryB :public Factory {
public:
    virtual Produs* createProdus() override {
        return new Iphone();
    }
};

int main()
{
    FactoryA factoriA;

    Produs* Samsung = factoriA.createProdus();
    Samsung->setName("Samsung GALAXY S23");
    Samsung->setPrice(5000.0);
    Samsung->setStock(200);
    Samsung->setCuloare("green");
    Samsung->setGB(500);
    Samsung->display();
    delete Samsung;

    FactoryB factoriB;

    Produs* Iphone = factoriB.createProdus();
    Iphone->setName("Iphone 15");
    Iphone->setPrice(7000.0);
    Iphone->setStock(500);
    Iphone->setCuloare("metal black");
    Iphone->setGB(232);
    Iphone->display();
    delete Iphone;

}



